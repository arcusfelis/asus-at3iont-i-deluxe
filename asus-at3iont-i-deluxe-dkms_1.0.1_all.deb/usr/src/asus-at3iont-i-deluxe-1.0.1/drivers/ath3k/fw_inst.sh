#!/bin/bash
FW_PATH="/lib/firmware/"
install drivers/ath3k/ath3k-1.fw $FW_PATH
